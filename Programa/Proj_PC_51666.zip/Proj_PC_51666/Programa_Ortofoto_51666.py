# -*- coding: utf-8 -*-
"""
Created on Mon Mar 22 14:35:42 2021

@author: Miguel
"""
import numpy as np
import math
import matplotlib.pyplot as plt
from imageio import imread, imwrite
import tifffile as tiff
plt.close('all');

#Imagem 10.tif
orto=tiff.imread('10.tif')
lin=orto.shape[0]
col=orto.shape[1]


#Imagem final vazia
Imagem_final=np.zeros((500,500,3))

#Orientações internas e externas da foto 10.
f=open('orientações externas.txt')
lines=f.readlines()

X0= float(lines[6][29:39])
Y0= float(lines[6][41:52])
Z0= float(lines[6][57:65])
w= float(lines[6][69:75])
fi= float(lines[6][79:85])
k= float(lines[6][88:95])

f.close()

#Parametros de orientação interna da câmera
c=0.12
x0=0
y0=0
pixel_size=12*10**(-6)
w_rad=w*math.pi/180
fi_rad=fi*math.pi/180
k_rad=k*math.pi/180

#Matriz de rotação
r11=(math.cos(fi_rad))*(math.cos(k_rad))
r12=-(math.cos(fi_rad))*(math.sin(k_rad))
r13=math.sin(fi_rad)
r21=(math.cos(w_rad))*(math.sin(k_rad))+(math.sin(w_rad))*(math.sin(fi_rad))*(math.cos(k_rad))
r22=(math.cos(w_rad))*(math.cos(k_rad))-(math.sin(w_rad))*(math.sin(fi_rad))*(math.sin(k_rad))
r23=-(math.sin(w_rad))*(math.cos(fi_rad))
r31=(math.sin(w_rad))*(math.sin(k_rad))-(math.cos(w_rad))*(math.sin(fi_rad))*(math.cos(k_rad))
r32=(math.sin(w_rad))*(math.cos(k_rad))+(math.cos(w_rad))*(math.sin(fi_rad))*(math.sin(k_rad))
r33=(math.cos(w_rad))*(math.cos(fi_rad))


#Importação da telha lidar
telha  = np.loadtxt("tile178arc", skiprows=6)


#Criação de 3 listas de 500x500 pixeis que contêm respetivamente
#a coordenada X,Y e Z presente em cada ponto da telha Lidar
X=np.zeros(telha.shape)
Y=np.zeros(telha.shape)
Z=np.zeros(telha.shape)
for i in range(500):
    for j in range(500):
        Xll=-89005.483600000007
        Yll=-100982.793600000000
        X[i][j]=(Xll+j)
        Y[i][j]=(Yll+i)
        Z[i][j]=(telha[i][j])
        
#Espelhamento das matrizes pois o valor (0,0) deve estar no CIE
X=np.flip(X,0)
Y=np.flip(Y,0)
Z=np.flip(Z,0)

#Aplicação das equações de colinearidade divididas em duas listas para x e y
eq_coli_x=np.zeros(telha.shape)
eq_coli_y=np.zeros(telha.shape)
for i in range(500):
    for j in range(500):
        Nx=r11*(X[i][j]-X0)+r21*(Y[i][j]-Y0)+r31*(Z[i][j]-Z0)
        Ny=r12*(X[i][j]-X0)+r22*(Y[i][j]-Y0)+r32*(Z[i][j]-Z0)
        D=r13*(X[i][j]-X0)+r23*(Y[i][j]-Y0)+r33*(Z[i][j]-Z0)
        eq_coli_x[i][j]=x0-c*(Nx/D)
        eq_coli_y[i][j]=y0-c*(Ny/D)

        

#Transformação das coordenadas foto vindas das Eq. Coli
#em coordenadas pixel (xp,yp)
xp=np.zeros(telha.shape)
yp=np.zeros(telha.shape)  
xci=np.zeros(telha.shape)
yci=np.zeros(telha.shape)  
for i in range(500):
    for j in range(500):
        xci[i][j]=eq_coli_x[i][j]/pixel_size
        yci[i][j]=eq_coli_y[i][j]/pixel_size
        xp[i][j]=xci[i][j]+col/2
        yp[i][j]=lin/2-yci[i][j]

#Ciclo que percorre as coordenadas xp,yp da foto 10.tif
r=0
z=0
for i in range(lin):
    for j in range(col):
        #Se a coordenada pixel na 10.tif for igual
        #a uma coordenada pixel inteira da telha
        if (j == int(xp[0][0])) and (i==int(yp[0][0])):
            for k in range(500):
                for l in range(500):
                    #Passar os 500 pixeis seguintes em x e y 
                    #para a imagem vazia 
                    Imagem_final[k][l][0]=orto[i+k][j+l][0]
                    Imagem_final[k][l][1]=orto[i+k][j+l][1]
                    Imagem_final[k][l][2]=orto[i+k][j+l][2]
            r=r+1
        else:
            z=z+1


#Output
I=np.uint8(Imagem_final)
plt.figure()
plt.imshow(I, "gray");plt.title("Ortofoto");plt.axis("off")